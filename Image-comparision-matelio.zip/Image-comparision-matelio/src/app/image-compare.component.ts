import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ImageService } from './image.service';
import { map } from 'rxjs/operators';
import { ImageInfo } from './image.model';
@Component({
  selector: 'app-Image-compare',
  templateUrl: './image-compare.component.html',
  styleUrls: ['./image-compare.component.scss']
})
export class ImageCompareComponent implements OnInit {
  imagesLimit = 10;
  imagesInformation: any;
  imagesTableInfo:  any = [];
  constructor(public imageInfo:ImageService) {}
  ngOnInit() { 
    this.getImagesData();
  }
  getImagesData() {
     this.imageInfo.getImagesandDetails().pipe(map(response => response.slice(0, this.imagesLimit))).subscribe((Info) => {
        this.imagesInformation = Info;
        this.imagesInformation.forEach((imgvalue:any) => {
            imgvalue['buttonvalue'] = 'COMPARE';
        });
     });
  }
  compareImages(id:number,buttonType: string) {
    this.imagesInformation.map((image:any) => {
       if(image.id == id) {
        if(buttonType == 'COMPARE') {
           image['buttonvalue'] = 'REMOVE';
           this.imagesTableInfo.push(image);
        } else {
            image['buttonvalue'] = 'COMPARE';
           this.imagesTableInfo.forEach((tableinfo: any,i: any) => {
               if(tableinfo.id == id) {
                   this.imagesTableInfo.splice(i,1);
               }
           });
        }
       }
    })
  }
}
