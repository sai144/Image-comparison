import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class ImageService {
imagesUrl = 'https://jsonplaceholder.typicode.com/photos';
   constructor(private http: HttpClient) { }

getImagesandDetails():Observable<any> {
  return this.http.get(this.imagesUrl);
}
}